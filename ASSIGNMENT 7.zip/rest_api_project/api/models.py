from django.db import models

class Student(models.Model):
    name = models.CharField(max_length=100)
    age = models.IntegerField()
    grade = models.CharField(max_length=10)
    date_of_birth = models.DateField()  # Added date field

    def __str__(self):
        return self.name
