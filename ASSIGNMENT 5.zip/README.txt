1. Run initial database setup:
   python manage.py makemigrations
   python manage.py migrate

2. Create a superuser:
   python manage.py createsuperuser

3. Start the server:
   python manage.py runserver

4. Open in browser:
   http://127.0.0.1:8000/ to view the blog

To add posts:
Go to http://127.0.0.1:8000/admin/, log in, and add new Posts.
