# Facebook Auto Blog Poster using Selenium

## ⚠️ Warning
This script uses Selenium to automate posting on Facebook. Automated interactions with Facebook may violate their terms of service. Use only for educational or testing purposes on dummy accounts.

## 📦 Requirements
- Python 3.7+
- Google Chrome
- Selenium
- webdriver-manager

## 🚀 How to Use
1. Replace `your_email`, `your_password`, and `post_content` in `auto_poster.py`
2. Install requirements:
   pip install -r requirements.txt
3. Run the script:
   python auto_poster.py

**Do not use your main Facebook account for testing this.**
