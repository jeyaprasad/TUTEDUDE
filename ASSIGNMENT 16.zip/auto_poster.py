from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
import time

# Replace with your Facebook credentials and post content
email = "your_email"
password = "your_password"
post_content = "Hello, this is an automated post using Selenium!"

# Setup Chrome browser
options = webdriver.ChromeOptions()
# options.add_argument("--headless")  # Uncomment to run in headless mode
driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)

# Navigate to Facebook login page
driver.get("https://www.facebook.com/")
time.sleep(2)

# Log into Facebook
driver.find_element(By.ID, "email").send_keys(email)
driver.find_element(By.ID, "pass").send_keys(password)
driver.find_element(By.NAME, "login").click()
time.sleep(5)

# Click on post box and write the post (for profile)
try:
    post_area = driver.find_element(By.XPATH, "//div[@aria-label='Create a post']")
    post_area.click()
    time.sleep(3)

    active_area = driver.find_element(By.XPATH, "//div[@role='dialog']//div[@aria-label='What's on your mind?']")
    active_area.click()
    active_area.send_keys(post_content)
    time.sleep(2)

    post_button = driver.find_element(By.XPATH, "//div[@aria-label='Post']")
    post_button.click()
    print("Post submitted successfully!")
except Exception as e:
    print("Could not create post:", e)

time.sleep(5)
driver.quit()
