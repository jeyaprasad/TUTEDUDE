from flask import Flask, render_template, request, redirect, flash
import sqlite3
import re

app = Flask(__name__)
app.secret_key = "your_secret_key"

# Database setup
def init_db():
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS users
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  username TEXT NOT NULL,
                  email TEXT NOT NULL UNIQUE,
                  password TEXT NOT NULL)""")
    conn.commit()
    conn.close()

@app.route('/')
def home():
    return redirect('/register')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        confirm = request.form['confirm']

        # Simple validations
        if not username or not email or not password or not confirm:
            flash("All fields are required!")
        elif password != confirm:
            flash("Passwords do not match!")
        elif not re.match(r"[^@]+@[^@]+\.[^@]+", email):
            flash("Invalid email address!")
        else:
            try:
                conn = sqlite3.connect('users.db')
                c = conn.cursor()
                c.execute("INSERT INTO users (username, email, password) VALUES (?, ?, ?)",
                          (username, email, password))
                conn.commit()
                conn.close()
                return render_template('success.html', username=username)
            except sqlite3.IntegrityError:
                flash("Email already registered!")

    return render_template('register.html')

if __name__ == '__main__':
    init_db()
    app.run(debug=True)
