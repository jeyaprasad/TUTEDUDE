from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
import time

# Setup Chrome browser
options = webdriver.ChromeOptions()
options.add_argument("--headless")  # Run in headless mode
driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)

# Replace with the URL you want to scrape
url = "https://quotes.toscrape.com"
driver.get(url)
time.sleep(2)  # Wait for the page to load

# Extract quotes and authors
quotes = driver.find_elements(By.CLASS_NAME, "text")
authors = driver.find_elements(By.CLASS_NAME, "author")

# Display scraped data
for quote, author in zip(quotes, authors):
    print(f"{quote.text} — {author.text}")

driver.quit()
