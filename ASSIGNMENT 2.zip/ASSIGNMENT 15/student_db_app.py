import psycopg2
import datetime

# Connect to PostgreSQL
try:
    conn = psycopg2.connect(
        dbname="postgres",          # Replace with your DB name if needed
        user="postgres",            # Replace with your PostgreSQL username
        password="1549",   # Replace with your PostgreSQL password
        host="localhost",
        port="5432"
    )
    cursor = conn.cursor()
    print("Connected to PostgreSQL Database")

    # Create the students table if it doesn't exist
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS students (
            id SERIAL PRIMARY KEY,
            name VARCHAR(100),
            age INT,
            grade VARCHAR(10)
        );
    """)
    conn.commit()
    print("Table 'students' is ready.")

    # Menu loop
    while True:
        print("\n===== Student Database Menu =====")
        print("1. Add a new student")
        print("2. View all students")
        print("3. Delete a student by ID")
        print("4. Exit")
        choice = input("Enter your choice (1-4): ")

        if choice == '1':
            # Add new student
            name = input("Enter student name: ")
            age = int(input("Enter student age: "))
            grade = input("Enter student grade: ")
            cursor.execute(
                "INSERT INTO students (name, age, grade) VALUES (%s, %s, %s);",
                (name, age, grade)
            )
            conn.commit()
            print("Student added successfully.")

        elif choice == '2':
            # View all students
            cursor.execute("SELECT * FROM students;")
            rows = cursor.fetchall()
            print("\nAll Students:")
            for row in rows:
                print(f"ID: {row[0]}, Name: {row[1]}, Age: {row[2]}, Grade: {row[3]}")
            print("Timestamp:", datetime.datetime.now())

        elif choice == '3':
            # Delete student by ID
            student_id = input("Enter student ID to delete: ")
            cursor.execute("DELETE FROM students WHERE id = %s;", (student_id,))
            conn.commit()
            print("Student deleted (if ID was valid).")

        elif choice == '4':
            print("Exiting the program.")
            break

        else:
            print("Invalid choice. Please enter a number from 1 to 4.")

    # Close the connection
    cursor.close()
    conn.close()
    print("Connection closed.")

except Exception as e:
    print("Error:", e)
