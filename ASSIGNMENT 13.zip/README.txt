Price Tracer for Samsung S25 (Amazon)

This script fetches the price of the Samsung S25 from Amazon.in and logs it to a CSV file.
