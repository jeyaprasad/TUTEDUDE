import requests
from bs4 import BeautifulSoup
from datetime import datetime
import csv

# Samsung S25 product URL (Amazon India)
URL = "https://www.amazon.in/dp/B0C7V9RWY8"
HEADERS = {
    "User-Agent": "Mozilla/5.0",
    "Accept-Language": "en-IN,en;q=0.9"
}

def fetch_price():
    try:
        response = requests.get(URL, headers=HEADERS)
        response.raise_for_status()

        soup = BeautifulSoup(response.content, "html.parser")

        # Extract product title
        title = soup.find(id="productTitle").get_text().strip()

        # Extract price (you may need to adjust class name if it changes)
        price_tag = soup.find("span", {"class": "a-price-whole"})
        if price_tag:
            price = price_tag.get_text().strip()
        else:
            price = "Not Available"

        print(f"{datetime.now()} | {title} | ₹{price}")
        save_to_csv(datetime.now(), title, price)

    except Exception as e:
        print("Error:", e)

def save_to_csv(date, title, price):
    with open("price_log.csv", "a", newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        writer.writerow([date, title, price])

if __name__ == "__main__":
    fetch_price()
